(() => {
	'use strict';

	const CC = (globalThis.ClaudeCounter = globalThis.ClaudeCounter || {});

	CC.DOM = Object.freeze({
		// Legacy selector (kept as fallback for older claude.ai builds)
		CHAT_MENU_TRIGGER_LEGACY: '[data-testid="chat-menu-trigger"]',
		// New claude.ai UI (2026): the "chat-menu-trigger" testid was removed.
		// The "more options" icon button next to the chat title is the closest stable anchor.
		// Its aria-label is "More options for <chat title>" (dynamic suffix), so match on the prefix.
		CHAT_MENU_TRIGGER: '[data-testid="chat-title-split"] [data-cds-icon-only][aria-label^="More options for"], [data-testid="chat-menu-trigger"]',
		CHAT_TITLE_SPLIT: '[data-testid="chat-title-split"]',
		MODEL_SELECTOR_DROPDOWN: '[data-testid="model-selector-dropdown"]',
		// Legacy wrapper class (no longer present in new UI) - kept as fallback only.
		CHAT_PROJECT_WRAPPER: '.chat-project-wrapper',
		BRIDGE_SCRIPT_ID: 'cc-bridge-script'
	});

	CC.CONST = Object.freeze({
		CACHE_WINDOW_MS: 5 * 60 * 1000,
		CONTEXT_LIMIT_TOKENS: 200000
	});

	CC.COLORS = Object.freeze({
		PROGRESS_FILL_DARK: '#2c84db',
		PROGRESS_FILL_LIGHT: '#5aa6ff',
		PROGRESS_OUTLINE_DARK: '#787877',
		PROGRESS_OUTLINE_LIGHT: '#bfbfbf',
		PROGRESS_MARKER_DARK: '#ffffff',
		PROGRESS_MARKER_LIGHT: '#111111',
		RED_WARNING: '#ce2029',
		BOLD_LIGHT: '#141413',
		BOLD_DARK: '#faf9f5'
	});
})();
